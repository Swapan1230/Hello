Page Object Model Design Pattern:
Reporting: Jasmine2 Htlm Reporting 
Log: npm winston to get log information 
Data Driven: using json file.
Send email: 
Batch File: to running the project use Prunner.bat file